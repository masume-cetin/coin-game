﻿
namespace TaşToplamaOyunu
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Seviye = new System.Windows.Forms.ComboBox();
            this.TaşSeçim = new System.Windows.Forms.ComboBox();
            this.oyun = new System.Windows.Forms.RadioButton();
            this.restart = new System.Windows.Forms.Button();
            this.Board3 = new System.Windows.Forms.Panel();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Ravie", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.OrangeRed;
            this.label2.Location = new System.Drawing.Point(453, 41);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(645, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "YERLEŞTİRMEK İSTEDİĞİNİZ TAŞ TÜRÜNÜ SEÇİNİZ";
            // 
            // Seviye
            // 
            this.Seviye.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.Seviye.FormattingEnabled = true;
            this.Seviye.Items.AddRange(new object[] {
            "Seviye 1",
            "Seviye 2"});
            this.Seviye.Location = new System.Drawing.Point(1054, 108);
            this.Seviye.Name = "Seviye";
            this.Seviye.Size = new System.Drawing.Size(164, 24);
            this.Seviye.TabIndex = 2;
            this.Seviye.Text = "Seviye 3";
            // 
            // TaşSeçim
            // 
            this.TaşSeçim.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.TaşSeçim.FormattingEnabled = true;
            this.TaşSeçim.Items.AddRange(new object[] {
            "yantaş",
            "engel"});
            this.TaşSeçim.Location = new System.Drawing.Point(1181, 44);
            this.TaşSeçim.Name = "TaşSeçim";
            this.TaşSeçim.Size = new System.Drawing.Size(121, 24);
            this.TaşSeçim.TabIndex = 3;
            this.TaşSeçim.Text = "Taş Türü Seçiniz";
            // 
            // oyun
            // 
            this.oyun.AutoSize = true;
            this.oyun.BackColor = System.Drawing.Color.Transparent;
            this.oyun.Font = new System.Drawing.Font("Ravie", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oyun.ForeColor = System.Drawing.Color.OrangeRed;
            this.oyun.Location = new System.Drawing.Point(719, 108);
            this.oyun.Name = "oyun";
            this.oyun.Size = new System.Drawing.Size(224, 26);
            this.oyun.TabIndex = 4;
            this.oyun.TabStop = true;
            this.oyun.Text = "oynamaya başla";
            this.oyun.UseVisualStyleBackColor = false;
            // 
            // restart
            // 
            this.restart.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.restart.Location = new System.Drawing.Point(868, 150);
            this.restart.Name = "restart";
            this.restart.Size = new System.Drawing.Size(75, 31);
            this.restart.TabIndex = 5;
            this.restart.Text = "tekrar";
            this.restart.UseVisualStyleBackColor = false;
            this.restart.Click += new System.EventHandler(this.restart_Click);
            // 
            // Board3
            // 
            this.Board3.Location = new System.Drawing.Point(414, 187);
            this.Board3.Name = "Board3";
            this.Board3.Size = new System.Drawing.Size(1027, 686);
            this.Board3.TabIndex = 6;
            // 
            // exit
            // 
            this.exit.BackColor = System.Drawing.Color.DarkSeaGreen;
            this.exit.Location = new System.Drawing.Point(1004, 150);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 27);
            this.exit.TabIndex = 7;
            this.exit.Text = "çıkış";
            this.exit.UseVisualStyleBackColor = false;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1640, 969);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.Board3);
            this.Controls.Add(this.restart);
            this.Controls.Add(this.oyun);
            this.Controls.Add(this.TaşSeçim);
            this.Controls.Add(this.Seviye);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form3";
            this.Text = "SEVİYE 3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Seviye;
        private System.Windows.Forms.ComboBox TaşSeçim;
        private System.Windows.Forms.RadioButton oyun;
        private System.Windows.Forms.Button restart;
        private System.Windows.Forms.Panel Board3;
        private System.Windows.Forms.Button exit;
    }
}