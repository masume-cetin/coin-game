﻿
namespace TaşToplamaOyunu
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.label1 = new System.Windows.Forms.Label();
            this.TaşSeçim = new System.Windows.Forms.ComboBox();
            this.oyun = new System.Windows.Forms.CheckBox();
            this.Board2 = new System.Windows.Forms.Panel();
            this.Seviye = new System.Windows.Forms.ComboBox();
            this.restart = new System.Windows.Forms.Button();
            this.exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Ravie", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Orange;
            this.label1.Location = new System.Drawing.Point(505, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(542, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "yerleştirmek istediğiniz taş türünü seçiniz";
            // 
            // TaşSeçim
            // 
            this.TaşSeçim.BackColor = System.Drawing.SystemColors.HighlightText;
            this.TaşSeçim.FormattingEnabled = true;
            this.TaşSeçim.Items.AddRange(new object[] {
            "yantaş",
            "engel"});
            this.TaşSeçim.Location = new System.Drawing.Point(1087, 20);
            this.TaşSeçim.Name = "TaşSeçim";
            this.TaşSeçim.Size = new System.Drawing.Size(136, 24);
            this.TaşSeçim.TabIndex = 1;
            this.TaşSeçim.Text = "taş türü seçiniz";
            // 
            // oyun
            // 
            this.oyun.AutoSize = true;
            this.oyun.BackColor = System.Drawing.Color.Transparent;
            this.oyun.Font = new System.Drawing.Font("Ravie", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oyun.ForeColor = System.Drawing.Color.Orange;
            this.oyun.Location = new System.Drawing.Point(719, 62);
            this.oyun.Name = "oyun";
            this.oyun.Size = new System.Drawing.Size(225, 26);
            this.oyun.TabIndex = 2;
            this.oyun.Text = "oynamaya başla";
            this.oyun.UseVisualStyleBackColor = false;
            // 
            // Board2
            // 
            this.Board2.Location = new System.Drawing.Point(592, 178);
            this.Board2.Name = "Board2";
            this.Board2.Size = new System.Drawing.Size(694, 598);
            this.Board2.TabIndex = 3;
            // 
            // Seviye
            // 
            this.Seviye.FormattingEnabled = true;
            this.Seviye.Items.AddRange(new object[] {
            "Seviye 1",
            "Seviye 3"});
            this.Seviye.Location = new System.Drawing.Point(991, 62);
            this.Seviye.Name = "Seviye";
            this.Seviye.Size = new System.Drawing.Size(121, 24);
            this.Seviye.TabIndex = 4;
            this.Seviye.Text = "Seviye 2";
            // 
            // restart
            // 
            this.restart.Location = new System.Drawing.Point(901, 118);
            this.restart.Name = "restart";
            this.restart.Size = new System.Drawing.Size(75, 23);
            this.restart.TabIndex = 5;
            this.restart.Text = "tekrar";
            this.restart.UseVisualStyleBackColor = true;
            this.restart.Click += new System.EventHandler(this.restart_Click);
            // 
            // exit
            // 
            this.exit.Location = new System.Drawing.Point(901, 149);
            this.exit.Name = "exit";
            this.exit.Size = new System.Drawing.Size(75, 23);
            this.exit.TabIndex = 6;
            this.exit.Text = "çıkış";
            this.exit.UseVisualStyleBackColor = true;
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1902, 1055);
            this.Controls.Add(this.exit);
            this.Controls.Add(this.restart);
            this.Controls.Add(this.Seviye);
            this.Controls.Add(this.Board2);
            this.Controls.Add(this.oyun);
            this.Controls.Add(this.TaşSeçim);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "SEVİYE 2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox TaşSeçim;
        private System.Windows.Forms.CheckBox oyun;
        private System.Windows.Forms.Panel Board2;
        private System.Windows.Forms.ComboBox Seviye;
        private System.Windows.Forms.Button restart;
        private System.Windows.Forms.Button exit;
    }
}