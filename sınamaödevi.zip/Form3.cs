﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using tahtamodelleme;

namespace TaşToplamaOyunu
{
    public partial class Form3 : Form
    {
        class Location
        {
            public int X;
            public int Y;
            public int F;
            public int G;
            public int H;
            public Location Parent;
        }
        List<int> trailpos = new List<int>();
        List<int> engelxpos = new List<int>();
        List<int> engelypos = new List<int>();
        List<int> xpos = new List<int>();
        List<int> ypos = new List<int>();
        int t = 0;
        static Board myboard = new Board(15);
        public Button[,] btnGrid = new Button[myboard.size, myboard.size];
        int mainTaşX = 0;
        int mainTaşY = 0;
        int check = 0;
        int eng = 0;
        int keeptrack = 0;
        int trail = 0;
        int trail1 = 0;
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            populateGrid(15);
        }
        private void populateGrid(int a)
        {

            Board3.Height = this.Height - 270;
            Board3.Width = Board3.Height;

            myboard.size = a;

            int buttonSize = Board3.Width / myboard.size;

            Board3.BackColor = Color.Transparent;


            for (int i = 0; i < myboard.size; i++)
            {
                for (int j = 0; j < myboard.size; j++)
                {
                    btnGrid[i, j] = new Button();
                    btnGrid[i, j].Width = buttonSize;
                    btnGrid[i, j].Height = buttonSize;
                    btnGrid[i, j].Click += Grid_Button_Click;
                    Board3.Controls.Add(btnGrid[i, j]);
                    btnGrid[i, j].Text = " ";
                    btnGrid[i, j].Location = new Point(i * buttonSize, j * buttonSize);
                    btnGrid[i, j].FlatStyle = FlatStyle.Flat;
                    btnGrid[i, j].BackColor = Color.AliceBlue;
                    btnGrid[i, j].Tag = new Point(i, j);
                }
            }
            Random rnd = new Random();
            mainTaşX = rnd.Next(1, myboard.size);
            mainTaşY = rnd.Next(1, myboard.size);
            btnGrid[mainTaşX, mainTaşY].Location = new Point(mainTaşX * buttonSize, mainTaşY * buttonSize);
            myboard.TheGrid[mainTaşX, mainTaşY].CurrentlyOccupied = false;
            btnGrid[mainTaşX, mainTaşY].Text = "B";
            btnGrid[mainTaşX, mainTaşY].BackgroundImage = TaşToplamaOyunu.Properties.Resources.sandık3;
            trailpos.Add(0);
            Seviye.SelectedValueChanged += combobox_changed;

        }
        private void combobox_changed(object sender, EventArgs e)
        {
            if (trail == 0)
            {
                if (Seviye.SelectedItem == "Seviye 1")
                {
                    trail++;
                    MessageBox.Show("seviye 1 hazırlanıyor");
                    this.Hide();
                    Form1 frm2 = new Form1();
                    frm2.Size = new Size(1000, 1000);
                    frm2.Show();

                }
            }
            if (trail1 == 0)
            {
                if (Seviye.SelectedItem == "Seviye 2")
                {
                    trail1++;
                    MessageBox.Show("seviye 2 hazırlanıyor");
                    this.Hide();
                    Form2 frm2 = new Form2();
                    frm2.Size = new Size(1500, 1000);
                    frm2.Show();

                }
            }

        }

        private void Grid_Button_Click(object sender, EventArgs e)
        {

            if (TaşSeçim.SelectedItem.ToString() == "engel" && oyun.Checked == false)
            {
                if (eng < 12) { 
                Button Ybutton = (Button)sender;
                Point location = (Point)Ybutton.Tag;

                int x = location.X;
                int y = location.Y;
                engelxpos.Add(x);
                engelypos.Add(y);

                Cell currentcell = myboard.TheGrid[x, y];

                myboard.MarkNewxtLegalMoves(x, y, currentcell, "Ytaş");


                if (myboard.TheGrid[x, y].CurrentlyOccupied == false)
                {
                    //btnGrid[x, y].Text = "ENGEL";
                    myboard.TheGrid[x, y].CurrentlyOccupied = true;
                    btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.dragon3;

                }
                else
                {
                    MessageBox.Show("ATTENTİON : MİGHTY DRAGON LİVES HERE DONT DİSTURB");
                }
                    eng++;
            }
            }

            if (TaşSeçim.SelectedItem.ToString() == "yantaş" && oyun.Checked == false)
            {
                if (t < 15)
                {
                    Button Ybutton = (Button)sender;
                    Point location = (Point)Ybutton.Tag;

                    int x = location.X;
                    int y = location.Y;
                    xpos.Add(x);
                    ypos.Add(y);

                    Cell currentcell = myboard.TheGrid[x, y];

                    myboard.MarkNewxtLegalMoves(x, y, currentcell, "Ytaş");


                    if (myboard.TheGrid[x, y].CurrentlyOccupied == false)
                    {
                        //btnGrid[x, y].Text = "yantaş";
                        myboard.TheGrid[x, y].CurrentlyOccupied = true;
                        btnGrid[x, y].Text = "coin";
                        btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.coin1;
                        t++;
                    }
                    else
                    {
                        MessageBox.Show("this place already has an item on it");
                    }

                }
            }

            if (oyun.Checked == true)
            {
                for (int i = 0; i < xpos.Count; i++)
                {
                    if (btnGrid[xpos[i], ypos[i]].Text == "coin")
                    {

                        var start = new Location { X = xpos[i] + 1, Y = ypos[i] + 1 };
                        var target = new Location { X = mainTaşX + 1, Y = mainTaşY + 1 };

                        string[] map = new string[]
              {
                "+---------------+",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "|               |",
                "+---------------+",
              };

                        StringBuilder row1 = new StringBuilder();
                        row1.Append(map[ypos[i] + 1]);
                        row1.Remove(xpos[i] + 1, 1);
                        row1.Insert(xpos[i] + 1, "A");
                        map[ypos[i]] = row1.ToString();
                        row1.Clear();

                        for (int j = 0; j < engelxpos.Count; j++)
                        {
                            row1.Append(map[engelypos[j] + 1]);
                            row1.Remove(engelxpos[j] + 1, 1);
                            row1.Insert(engelxpos[j] + 1, "X");
                            map[engelypos[j] + 1] = row1.ToString();
                            row1.Clear();


                        }
                        row1.Append(map[mainTaşY + 1]);
                        row1.Remove(mainTaşX + 1, 1);
                        row1.Insert(mainTaşX + 1, "B");
                        map[mainTaşY] = row1.ToString();

                        btnGrid[xpos[i], ypos[i]].Text = LetsDoIt(map, start, target).ToString();
                    }

                }
                int c;
                int d;

                for (int i = 0; i < xpos.Count; i++)
                {
                    c = xpos[i];
                    d = ypos[i];
                    myboard.TheGrid[c, d].CurrentlyOccupied = false;

                }
                Button Ybutton = (Button)sender;
                Point location = (Point)Ybutton.Tag;

                int x = location.X;
                int y = location.Y;



              


                for (int i = trailpos[0]; i < xpos.Count; i++)
                {
                    if (myboard.TheGrid[x, y].CurrentlyOccupied == false)
                    {
                        if (x == xpos[i] && y == ypos[i])
                        {

                            btnGrid[x, y].BackgroundImage = null;
                            btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.coin1;
                            xpos[i] = x;
                            ypos[i] = y;
                            trailpos[0] = i;
                            if (x == mainTaşX && y == mainTaşY)
                            {
                                trailpos[0] = 0;
                                btnGrid[x, y].BackgroundImage = null;
                                btnGrid[mainTaşX, mainTaşY].BackgroundImage = TaşToplamaOyunu.Properties.Resources.sandık3;
                                if (Convert.ToInt32(btnGrid[x, y].Text) == 0 || Convert.ToInt32(btnGrid[x, y].Text) > 0)
                                {
                                    check++;

                                    if (check == xpos.Count)
                                    {
                                        MessageBox.Show("CONGRATS");
                                    }
                                }
                                else
                                {

                                    DialogResult result = MessageBox.Show("FAİL");
                                    if (result == DialogResult.OK)
                                    {
                                        restart_Click(sender, e);
                                    }

                                }

                            }
                            break;
                        }
                        else if (x == xpos[i] - 1 && y == ypos[i])
                        {
                            btnGrid[x, y].Text = (Convert.ToInt32(btnGrid[x + 1, y].Text) - 1).ToString();
                            btnGrid[x + 1, y].Text = " ";
                            btnGrid[x + 1, y].BackgroundImage = null;
                            btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.coin1;
                            xpos[i] = x;
                            ypos[i] = y;
                            trailpos[0] = i;
                            if (x == mainTaşX && y == mainTaşY)
                            {
                                trailpos[0] = 0;
                                btnGrid[x, y].BackgroundImage = null;
                                btnGrid[mainTaşX, mainTaşY].BackgroundImage = TaşToplamaOyunu.Properties.Resources.sandık3;
                                if (Convert.ToInt32(btnGrid[x, y].Text) == 0 || Convert.ToInt32(btnGrid[x, y].Text) > 0)
                                {
                                    check++;

                                    if (check == xpos.Count)
                                    {
                                        MessageBox.Show("CONGRATS");
                                    }
                                }
                                else
                                {

                                    DialogResult result = MessageBox.Show("FAİL");
                                    if (result == DialogResult.OK)
                                    {
                                        restart_Click(sender, e);
                                    }

                                }

                            }
                            break;
                        }
                        else if (x == xpos[i] && y == ypos[i] - 1)
                        {
                            btnGrid[x, y].Text = (Convert.ToInt32(btnGrid[x, y + 1].Text) - 1).ToString();
                            btnGrid[x, y + 1].Text = " ";
                            btnGrid[x, y + 1].BackgroundImage = null;

                            btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.coin1;
                            xpos[i] = x;
                            ypos[i] = y;
                            trailpos[0] = i;
                            if (x == mainTaşX && y == mainTaşY)
                            {
                                trailpos[0] = 0;
                                btnGrid[x, y].BackgroundImage = null;
                                btnGrid[mainTaşX, mainTaşY].BackgroundImage = TaşToplamaOyunu.Properties.Resources.sandık3;
                                if (Convert.ToInt32(btnGrid[x, y].Text) == 0 || Convert.ToInt32(btnGrid[x, y].Text) > 0)
                                {
                                    check++;

                                    if (check == xpos.Count)
                                    {
                                        MessageBox.Show("CONGRATS");
                                    }
                                }
                                else
                                {

                                    DialogResult result = MessageBox.Show("FAİL");
                                    if (result == DialogResult.OK)
                                    {
                                        restart_Click(sender, e);
                                    }

                                }

                            }
                            break;

                        }
                        else if (x == xpos[i] + 1 && y == ypos[i])
                        {
                            btnGrid[x, y].Text = (Convert.ToInt32(btnGrid[x - 1, y].Text) - 1).ToString();
                            btnGrid[x - 1, y].Text = " ";
                            btnGrid[x - 1, y].BackgroundImage = null;

                            btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.coin1;
                            xpos[i] = x;
                            ypos[i] = y;
                            trailpos[0] = i;
                            if (x == mainTaşX && y == mainTaşY)
                            {
                                trailpos[0] = 0;
                                btnGrid[x, y].BackgroundImage = null;
                                btnGrid[mainTaşX, mainTaşY].BackgroundImage = TaşToplamaOyunu.Properties.Resources.sandık3;
                                if (Convert.ToInt32(btnGrid[x, y].Text) == 0 || Convert.ToInt32(btnGrid[x, y].Text) > 0)
                                {
                                    check++;

                                    if (check == xpos.Count)
                                    {
                                        MessageBox.Show("CONGRATS");
                                    }
                                }
                                else
                                {

                                    DialogResult result = MessageBox.Show("FAİL");
                                    if (result == DialogResult.OK)
                                    {
                                        restart_Click(sender, e);
                                    }

                                }

                            }
                            break;
                        }
                        else if (x == xpos[i] && y == ypos[i] + 1)
                        {
                            btnGrid[x, y].Text = (Convert.ToInt32(btnGrid[x, y - 1].Text) - 1).ToString();
                            btnGrid[x, y - 1].Text = " ";
                            btnGrid[x, y - 1].BackgroundImage = null;

                            btnGrid[x, y].BackgroundImage = TaşToplamaOyunu.Properties.Resources.coin1;
                            xpos[i] = x;
                            ypos[i] = y;
                            trailpos[0] = i;
                            if (x == mainTaşX && y == mainTaşY)
                            {
                                trailpos[0] = 0;
                                btnGrid[x, y].BackgroundImage = null;
                                btnGrid[mainTaşX, mainTaşY].BackgroundImage = TaşToplamaOyunu.Properties.Resources.sandık3;
                                if (Convert.ToInt32(btnGrid[x, y].Text) == 0 || Convert.ToInt32(btnGrid[x, y].Text) > 0)
                                {
                                    check++;

                                    if (check == xpos.Count)
                                    {
                                        MessageBox.Show("CONGRATS");
                                    }
                                }
                                else
                                {

                                    DialogResult result = MessageBox.Show("FAİL");
                                    if (result == DialogResult.OK)
                                    {
                                        restart_Click(sender, e);
                                    }

                                }

                            }
                            break;
                        }
                    }
                    else
                    {
                        string alert = "ATTENTİON : MİGHTY DRAGON SLEEPS HERE DONT DİSTURB";
                        MessageBox.Show(alert);
                        break;
                    }

                }


            }


        }


        static int LetsDoIt(string[] map, Location start, Location target)
        {
            Location current = null;
            var openList = new List<Location>();
            var closedList = new List<Location>();
            int g = 0;

            // start by adding the original position to the open list
            openList.Add(start);

            while (openList.Count > 0)
            {
                // get the square with the lowest F score
                var lowest = openList.Min(l => l.F);
                current = openList.First(l => l.F == lowest);

                // add the current square to the closed list
                closedList.Add(current);

                // remove it from the open list
                openList.Remove(current);

                // if we added the destination to the closed list, we've found a path
                if (closedList.FirstOrDefault(l => l.X == target.X && l.Y == target.Y) != null)
                    break;

                var adjacentSquares = GetWalkableAdjacentSquares(current.X, current.Y, map);
                g++;

                foreach (var adjacentSquare in adjacentSquares)
                {
                    // if this adjacent square is already in the closed list, ignore it
                    if (closedList.FirstOrDefault(l => l.X == adjacentSquare.X
                            && l.Y == adjacentSquare.Y) != null)
                        continue;

                    // if it's not in the open list...
                    if (openList.FirstOrDefault(l => l.X == adjacentSquare.X
                            && l.Y == adjacentSquare.Y) == null)
                    {
                        // compute its score, set the parent
                        adjacentSquare.G = g;
                        adjacentSquare.H = ComputeHScore(adjacentSquare.X, adjacentSquare.Y, target.X, target.Y);
                        adjacentSquare.F = adjacentSquare.G + adjacentSquare.H;
                        adjacentSquare.Parent = current;

                        // and add it to the open list
                        openList.Insert(0, adjacentSquare);
                    }
                    else
                    {
                        // test if using the current G score makes the adjacent square's F score
                        // lower, if yes update the parent because it means it's a better path
                        if (g + adjacentSquare.H < adjacentSquare.F)
                        {
                            adjacentSquare.G = g;
                            adjacentSquare.F = adjacentSquare.G + adjacentSquare.H;
                            adjacentSquare.Parent = current;
                        }
                    }
                }
            }

            int count = 0;
            // assume path was found; let's show it
            while (current != null)
            {
                current = current.Parent;
                count++;
            }

            // end

            return count - 1;
        }

        static List<Location> GetWalkableAdjacentSquares(int x, int y, string[] map)
        {


            var proposedLocations = new List<Location>()
            {
                new Location { X = x, Y = y - 1 },
                new Location { X = x, Y = y + 1 },
                new Location { X = x - 1, Y = y },
                new Location { X = x + 1, Y = y },
            };
            if (x == 1)
            {
                proposedLocations[2] = new Location { X = x, Y = y };
            }
            if (y == 1)
            {
                proposedLocations[0] = new Location { X = x, Y = y + 1 };
            }


            return proposedLocations.Where(l => map[l.Y][l.X] == ' ' || map[l.Y][l.X] == 'B').ToList();
        }


        static int ComputeHScore(int x, int y, int targetX, int targetY)
        {
            return Math.Abs(targetX - x) + Math.Abs(targetY - y);
        }

       

        private void restart_Click(object sender, EventArgs e)
        {
            mainTaşX = 0;
            mainTaşY = 0;
            check = 0;
            t = 0;
            eng = 0;
            trailpos[0] = 0;
            engelxpos.Clear();
            engelypos.Clear();
            xpos.Clear();
            ypos.Clear();
            oyun.Checked = false;
            for (int i = 0; i < myboard.size; i++)
            {
                for (int j = 0; j < myboard.size; j++)
                {
                    myboard.TheGrid[i, j].CurrentlyOccupied = false;
                    btnGrid[i, j].Dispose();

                }
            }
            populateGrid(15);
        }

        private void exit_Click(object sender, EventArgs e)
        {
            Application.OpenForms["Form1"].Close();
        }
    }
}
